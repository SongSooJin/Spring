<template>
  <div id="orderHeader">
    <logo></logo>
    <h1>
      <i class="fas fa-wallet"></i>주문결제
    </h1>
  </div>
</template>

<script>
import logo from "@/components/etc/logo.vue";
export default {
  components: {
    logo: logo
  }
};
</script>

<style>
</style>
