<template>
  <span>
    <U>우리은행 채무지급보증 안내</U>
    <br>당사는 고객님이 현금 결제한 금액에 대해
    <br>우리은행과 채무지급보증 계약을 체결하여
    <br>안전거래를 보장하고 있습니다.
  </span>
</template>

<script>
export default {};
</script>

<style>
</style>
