<template>
  <span>
    수진(주) | 대표이사 : 천곤홍
    <br>서울시 강남구 언주로30길 56
    <br>사업자 등록번호 : 015-01-71998
    <br>통신판매업신고 : 2018-서울도곡-0001
  </span>
</template>

<script>
export default {};
</script>

<style>
</style>
