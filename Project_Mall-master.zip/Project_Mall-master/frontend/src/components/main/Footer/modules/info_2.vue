<template>
  <span>

    <b>365고객센터</b> | 전자금융거래분쟁처리담당
    <br> <b>02-851-4790</b>
    <br> 686-53 프레콘빌딩 501호, 동작구 서울특별시
    <br> Fax : 02-851-4790| email : help@soojin.com
  </span>
</template>
<script>
export default {};
</script>

<style>

</style>
